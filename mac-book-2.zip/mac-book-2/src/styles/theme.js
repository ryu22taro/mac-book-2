const theme = {
  colors: {
    primary: "#0070f3",
    background: "#0a192f",
    text: "#ffffff",
  },
};

export default theme;
